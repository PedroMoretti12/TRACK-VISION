package app

import com.github.britooo.looca.api.core.Looca
import javax.swing.JOptionPane


open class Main {
    companion object {
        @JvmStatic fun main(args: Array<String>) {

            val repositorio = Looca()

            println("${repositorio.sistema}\n")
            println("${repositorio.processador} \n")

            while (true){
             val escolha =   JOptionPane.showInputDialog("""Seja Bem Vindo ao Jar Track Capture.
                    1-Memoria - Uso da Memória
                    2-Cpu - Uso da CPU
                    3-Disco - Disco Disponível
                    NDA-Sair
                """.trimIndent())
            when(escolha)  {
                "1" -> println("Uso de Memoria: "+(repositorio.memoria.emUso/1024/1024/1024).toString() + " GB")
                "2" -> println("Uso da CPU: "+((repositorio.processador.uso).toInt()).toString() + " %")
                "3" -> println("Disco Disponivel: "+(repositorio.grupoDeDiscos.volumes[0].disponivel/1024/1024/1024).toString()+" GB Livres")
                else -> break
            }
            }
        }
    }
}