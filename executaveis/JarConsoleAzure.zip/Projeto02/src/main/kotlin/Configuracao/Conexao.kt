package Configuracao

import org.apache.commons.dbcp2.BasicDataSource
import org.springframework.jdbc.core.JdbcTemplate

class Conexao {
    val driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver"
    val url = "jdbc:sqlserver://trackvisiondb.database.windows.net;databaseName=trackvisiondb;"
    val username = "CloudSA49c766d4"
    val password = "Urubu1004"
    fun getJdbcTemplate(): JdbcTemplate {
        val dataSource = BasicDataSource();
        dataSource.driverClassName = driver
        dataSource.url = url
        dataSource.username = username
        dataSource.password = password
        return JdbcTemplate(dataSource)
    }

    fun inserir(cpu:Double,disco:Double,ram:Double){
        val conexao = getJdbcTemplate()
        conexao.update("DECLARE @Date DATETIME; SET @Date = GETDATE(); insert into Leitura(fkBanco,fkAgencia,fkCaixa,cpuPorcentagem,ramPorcentagem,hdPorcentagem,momento) values(1,1,1,?,?,?,@Date)", cpu,ram,disco)
        conexao.update("DECLARE @Date DATETIME; SET @Date = GETDATE(); insert into Leitura(fkBanco,fkAgencia,fkCaixa,cpuPorcentagem,ramPorcentagem,hdPorcentagem,momento) values(1,1,1,?,?,?,@Date)", cpu*1.05,ram*1.00,disco*1.05)
        conexao.update("DECLARE @Date DATETIME; SET @Date = GETDATE(); insert into Leitura(fkBanco,fkAgencia,fkCaixa,cpuPorcentagem,ramPorcentagem,hdPorcentagem,momento) values(1,1,1,?,?,?,@Date)", cpu*1.20,ram*1.05,disco*1.20)
    }
}